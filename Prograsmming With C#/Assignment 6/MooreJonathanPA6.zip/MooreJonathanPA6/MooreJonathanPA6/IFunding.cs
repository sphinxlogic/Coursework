﻿//The IFunding Interface Definition.
using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment6
{
    public interface IFunding
    {
       void SetFundingAmt();
    }

    
}
