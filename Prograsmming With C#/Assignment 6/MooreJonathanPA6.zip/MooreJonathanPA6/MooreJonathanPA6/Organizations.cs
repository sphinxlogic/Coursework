﻿//The Intramural Class which has three variable declarations.

using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment6
{
    public class Organizations
    {
        public string name;
        public string contactperson;
        public decimal funding;



        
    }
}
